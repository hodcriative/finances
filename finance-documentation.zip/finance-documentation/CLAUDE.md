# Instruções para continuidade — FINANCE

Você está continuando o desenvolvimento de uma plataforma React de organização, análise e planejamento financeiro pessoal.

## 1. Escopo obrigatório

O produto é um **organizador financeiro pessoal**, não um banco e não uma carteira digital.

### NÃO implementar
- pagamentos reais;
- PIX;
- transferências bancárias reais;
- compras reais;
- investimentos reais;
- saque/depósito;
- conexão para movimentação de conta;
- execução de operações em cartão;
- cobrança ou processamento de cartão;
- qualquer integração que permita movimentar dinheiro.

### PODE implementar
- cadastro manual de receitas e despesas;
- contas como registros informativos;
- cartões como registros informativos;
- faturas lançadas/organizadas manualmente;
- orçamento;
- metas;
- categorias;
- análises e gráficos;
- alertas baseados nos dados cadastrados;
- indicadores e insights financeiros;
- autenticação/persistência quando definida a arquitetura de backend.

Sempre use linguagem que deixe claro que os dados são **manuais/representativos** quando houver risco de confusão com movimentação real.

## 2. Estado atual (pós Fase 2)

O código foi migrado da estrutura concentrada em `App.jsx`/`index.css` para a
arquitetura alvo descrita em `docs/02-ARCHITECTURE.md` (`app/`, `components/`,
`pages/`, `data/`, `hooks/`, `services/`, `utils/`, `styles/`).

Implementado nesta etapa:
- Rotas reais com React Router (`app/routes.jsx`), substituindo a leitura de
  `window.location.pathname`;
- Modelo de transação (`data/mockData.js`) e serviço de domínio
  (`services/transactionService.js`) com persistência em `localStorage`
  através de `services/storageService.js`;
- Estado central de transações via hook `hooks/useTransactions.js`
  (create/update/delete);
- Selectors financeiros centralizados em `utils/finance.js`
  (`getTotalIncome`, `getTotalExpenses`, `getBalance`, `getExpensesByCategory`,
  `getMonthlySeries`, `getBudgetUsage`, `getGoalProgress`), consumidos pelo
  hook `hooks/useFinanceSummary.js`;
- Página `/transacoes` completa: listagem, busca por descrição, filtros
  (período, tipo, categoria, conta/cartão), ordenação por data/valor,
  criação, edição e exclusão (com confirmação) de lançamentos, e estado
  vazio explicando o próximo passo;
- Dashboard consumindo os mesmos dados reais das transações: saldo,
  receitas, despesas, economia do mês, gráfico de evolução (6 meses) e
  gastos por categoria são todos derivados dos lançamentos, não mais
  hardcoded;
- Orçamento do mês no Dashboard já deriva a utilização por categoria dos
  lançamentos reais (`getBudgetUsage`); os limites em si continuam sendo
  dados representativos (Fase 4).
- Metas continuam com dados representativos (Fase 4), mas o progresso é
  calculado via `getGoalProgress` em vez de percentual fixo.

Implementado na Fase 3 (domínios de apoio):
- `services/categoryService.js` e `services/accountService.js`, no mesmo
  padrão de `transactionService.js` (CRUD + persistência via
  `storageService.js`);
- `hooks/useCategories.js` e `hooks/useAccounts.js`, no mesmo padrão de
  `useTransactions.js`;
- página `/cartoes` reescrita com três abas — **Cartões** (tiles com
  limite, fatura atual manual, dias de fechamento/vencimento), **Contas**
  (tipo, saldo inicial) e **Categorias** (nome, tipo, ícone, cor) — cada
  uma com criação, edição e desativação (a exclusão física existe nos
  serviços mas a UI usa desativação, para preservar transações já
  lançadas que referenciam o id);
- `TransactionForm`, `Transactions` e `Dashboard` passaram a ler
  categorias/contas dos novos hooks/serviços em vez de importar
  `categories`/`accounts` estaticamente de `data/mockData.js`;
- `data/mockData.js` ganhou os campos representativos de cartão (`brand`,
  `limit`, `currentInvoice`, `closingDay`, `dueDay`, `color`) e de conta
  (`type`, `initialBalance`, `color`), usados como seed inicial do
  `localStorage`.

Ainda são placeholders (usando o componente `components/ui/EmptyState.jsx`):
nenhuma página resta como placeholder puro — Configurações e Ajuda foram
implementadas (ver acima). O que ainda falta são os itens do RF10
explicitamente adiados (moeda, primeiro dia do mês financeiro,
segurança/login) e a própria Fase 6.

Implementado na Fase 5 (Análises):
- `utils/finance.js` ganhou `getPeriodComparison`, `getTopExpenses`,
  `getSpendingTrend` e `getCategoryShift`, todos reaproveitando os
  selectors já existentes (`getTotalIncome`/`getTotalExpenses`/
  `getSavingsRate`/`getExpensesByCategory`) em vez de recalcular do zero;
- `hooks/useAnalytics.js`, no mesmo padrão de `useFinanceSummary.js`;
- página `/analises`: seletor de mês, visão geral, evolução de 12 meses
  (reaproveitando `components/charts/FinancialChart.jsx`), distribuição por
  categoria (reaproveitando `components/charts/CategoryDonut.jsx`),
  comparação entre o mês selecionado e qualquer outro mês com lançamentos,
  maiores gastos (reaproveitando `components/finance/TransactionRow.jsx`
  em modo leitura), tendências/insights textuais e exportação em CSV do
  mês selecionado (gerada no navegador, sem backend).

Implementado em Configurações e Ajuda (após confirmação do usuário para
priorizar essa frente antes da Fase 6):
- `services/preferencesService.js`: registro único (não é uma lista, então
  sem CRUD) com `name`, `theme` (`"light"|"dark"`), `notifyBudgetAlerts` e
  `notifyGoalAlerts`, persistido em `localStorage` (chave `preferences`),
  seed em `data/mockData.js`;
- `app/PreferencesContext.jsx`: diferente dos outros domínios (que usam
  hook local por página lendo do `localStorage` a cada montagem), este
  usa React Context porque a Sidebar/Header ficam montadas o tempo todo e
  precisam refletir mudanças feitas em `/configuracoes` em tempo real;
  também aplica `document.documentElement.dataset.theme` para ativar o
  bloco `[data-theme="dark"]` de `styles/tokens.css`;
- `hooks/useAlerts.js`: extraído da página `/alertas` para ser reaproveitado
  também pelo indicador de notificações da Sidebar, aceitando
  `includeBudget`/`includeGoals` (vindos das preferências) para
  ocultar tipos de alerta;
- `Sidebar.jsx` e `Header.jsx` passaram a ler nome/inicial do avatar de
  `usePreferences()` em vez de string fixa; o indicador de alertas da
  Sidebar agora é a contagem real de `useAlerts()` (antes era um número
  fixo "3");
- página `/configuracoes`: formulário de nome (com validação), seletor de
  tema e checkboxes de notificação (aplicados imediatamente, sem botão
  salvar) e uma seção "Em definição" cobrindo moeda, primeiro dia do mês
  financeiro e segurança/login — itens do RF10 que dependem de decisões de
  produto/infra ainda não tomadas, então ficam documentados como
  pendentes em vez de implementados pela metade;
- página `/ajuda`: FAQ estático (sem dados dinâmicos) explicando o
  funcionamento de cada domínio já implementado;
- tema escuro: tokens `--bg`, `--surface`, `--surface-2`, `--text`,
  `--muted`, `--border` e `--primary-soft` ganharam um bloco
  `[data-theme="dark"]` em `styles/tokens.css`; um novo token
  `--surface-alt` (igual a `--surface` no tema claro) substituiu os
  `background: white` fixos de elementos "sobre o painel" (inputs de
  modal, ícones, chips) para que reajam ao tema. A sidebar permanece
  sempre escura nos dois temas. **Não coberto nesta etapa:** os fundos
  claros de estados de severidade (linha de orçamento excedido/próximo do
  limite, badges de alerta) continuam com os tons originais — um retoque
  fino por estado fica para uma próxima passada, se fizer sentido.

## 3. Próxima prioridade

Decisões da Fase 6 já alinhadas com o usuário: backend Node.js + Express +
SQLite (via `node:sqlite`, nativo do Node — sem dependência externa),
autenticação por e-mail/senha com JWT, sem provedor externo, e **sem**
migração automática do que já existe no `localStorage` (o backend começa
zerado por usuário).

Implementado nesta etapa — API completa em `server/` (ver
`server/README.md` para rotas e como rodar):
- `server/src/db.js`: schema SQLite espelhando `docs/04-DATA-MODEL.md`
  (users, preferences, categories, accounts — contas e cartões na mesma
  tabela via `kind`, como no frontend —, card_purchases, transactions,
  budgets, budget_categories, goals), tudo por `user_id`;
- `server/src/routes/auth.js`: registro (com hash `bcryptjs` e seed das
  mesmas categorias padrão de `data/mockData.js`), login, `/me`;
- `server/src/middleware/auth.js`: cada rota de domínio exige
  `Authorization: Bearer <token>` e filtra tudo por `req.userId`;
- rotas de domínio (`preferences`, `categories`, `accounts`,
  `card-purchases`, `transactions`, `budgets`, `goals`) espelhando byte a
  byte a lógica que já existia nos `services/*.js` do frontend (mesmos
  campos, mesmas regras — ex.: aporte de meta só soma ao valor acumulado,
  nunca transfere; total de compra parcelada é sempre derivado);
- testado manualmente via curl: registro/login/token inválido,
  fluxo completo de CRUD em cada domínio, e **isolamento entre usuários**
  (um usuário não lê, edita nem lança dados no que pertence a outro —
  contas/cartões, compras, transações, orçamento, metas).

Endurecido depois de uma pergunta direta do usuário sobre segurança
("vaza dado?"): rodei `npm audit` e havia 2 vulnerabilidades moderadas de
DoS num pacote transitivo do Express (`qs`) — corrigido via `overrides`
no `package.json` (0 vulnerabilidades depois). Além disso,
`server/src/utils/token.js` agora recusa subir o servidor com
`JWT_SECRET` ausente, igual ao placeholder de `.env.example`, ou menor
que 32 caracteres; e `server/src/routes/auth.js` ganhou rate limit
(`express-rate-limit`, 20 requisições/15min por IP) contra força bruta de
login.

Usuário perguntou em seguida se os itens pendentes dependiam da
integração do frontend — resposta: não, exceto verificação de e-mail
(depende de um provedor de envio externo, fora do alcance de rede deste
ambiente). Como revogação de sessão/logout é 100% backend, implementei
antes de ir para o frontend: tokens agora carregam um `jti` e só são
válidos enquanto existir a sessão correspondente na tabela `sessions`
(`server/src/db.js`); `POST /api/auth/logout` revoga a sessão do token em
uso, `POST /api/auth/logout-all` revoga todas as sessões do usuário.
Testado com múltiplas sessões simultâneas (revogar uma não afeta as
outras; logout-all derruba todas, inclusive a que o chamou) e reconfirmei
o resto da suíte de regressão (CRUD de todos os domínios + isolamento
entre usuários + rate limit) para garantir que a mudança não quebrou
nada.

O que continua deliberadamente fora do escopo (documentado em
"Segurança" em `server/README.md`, não é suposição minha de que "está
tudo bem"): HTTPS, verificação de e-mail, criptografia do arquivo SQLite
em disco — a API está adequada para desenvolvimento local e para a
próxima etapa (integração do frontend), mas não deve ser exposta na
internet sem resolver isso antes.

**O que falta para fechar a Fase 6** — combinado como próximo passo, ainda
não iniciado:
- trocar `src/services/*.js` de `localStorage` para chamadas `fetch` a
  esta API;
- telas de login/registro e proteção de rotas no `react-router`;
- guardar apenas o token no armazenamento local do navegador (não mais os
  dados inteiros).

Depois disso, resta do roadmap:
- dentro do RF10, moeda, primeiro dia do mês financeiro ficaram
  deliberadamente de fora desta etapa (documentados em "Em definição" na
  própria página `/configuracoes`) por dependerem de mudanças mais amplas
  (ex.: trocar a moeda exige revisar todo `utils/currency.js` e os pontos
  que assumem BRL/pt-BR hoje); segurança/login passa a fazer sentido só
  depois da integração do frontend com esta API;
- retoque fino de tema escuro em estados de severidade (linhas de
  orçamento excedido/próximo do limite, badges), hoje fora do escopo;
- Fase 7 (testes, acessibilidade, performance, deploy) vem depois da
  Fase 6.

## 4. Modelo de transação (implementado)

```js
{
  id: "uuid",
  type: "income" | "expense",
  description: "Supermercado",
  amount: 152.40,
  categoryId: "alimentacao",
  accountId: "nubank",
  date: "2026-09-04",
  notes: "Compra semanal",
  createdAt: "...",
  updatedAt: "..."
}
```

O valor deve ser armazenado como número positivo; o campo `type` determina se é receita ou despesa. Não armazenar despesa como número negativo na camada de domínio.

## 4.1 Modelo de conta/cartão/categoria (implementado na Fase 3)

Contas e cartões continuam na mesma coleção (`services/accountService.js`,
chave `accounts` no `localStorage`), diferenciados por `kind`:

```js
// conta
{ id, kind: "account", name, type: "checking"|"savings"|"cash"|"other", initialBalance, color, active }

// cartão representativo
{ id, kind: "card", name, brand, limit, currentInvoice, closingDay, dueDay, color, active }
```

`currentInvoice` é a fatura atual, informada e atualizada manualmente pelo
usuário — nunca calculada a partir de movimentações reais do cartão.

Compras parceladas por cartão (`services/cardPurchaseService.js`, chave
`cardPurchases`) — adicionado após a Fase 3, na aba **Compras** de
`/cartoes`:

```js
{ id, cardId, description, installmentAmount, installments }
```

`installmentAmount` é o valor pago por mês por aquela compra e
`installments` em quantas vezes ela foi dividida; o total da compra
(`installmentAmount * installments`) é sempre derivado via
`getPurchaseTotal`/`getCardPurchasesSummary` em `utils/finance.js`, nunca
armazenado, assim como o total mensal comprometido por cartão (exibido no
tile do cartão em `/cartoes`). Sem transações referenciando compras, a
exclusão é física.

Categorias (`services/categoryService.js`, chave `categories`):

```js
{ id, name, type: "income"|"expense"|"both", icon, color, active }
```

Exclusão de qualquer um dos três domínios é feita por **desativação**
(`active: false`) na UI, para não quebrar transações já lançadas que
referenciam o id; os serviços também expõem `remove()` para exclusão
física, mas a UI não a utiliza hoje.

## 4.2 Modelo de orçamento/meta (implementado na Fase 4)

Orçamento (`services/budgetService.js`, chave `budgets` — um registro por
mês):

```js
{ id, month: "2026-09", totalLimit, categories: [{ categoryId, limit }] }
```

`totalLimit` e cada `limit` por categoria são valores de referência
definidos pelo usuário na página `/orcamento`; a *utilização* continua
sendo sempre calculada a partir das despesas reais (`getBudgetUsage`,
`utils/finance.js`), nunca armazenada.

Metas (`services/goalService.js`, chave `goals`):

```js
{ id, title, targetAmount, currentAmount, deadline, icon, color, status: "active"|"paused"|"completed" }
```

Aporte (`addContribution`) apenas soma ao `currentAmount` já acumulado —
é sempre um registro/planejamento manual, nunca uma transferência real
entre contas ou cartões. O status muda para `"completed"` automaticamente
quando `currentAmount` atinge `targetAmount` (a não ser que a meta esteja
`"paused"`). Como nenhuma transação referencia uma meta, a exclusão em
`goalService.remove()` é física.

Alertas (`/alertas`) não têm serviço/coleção própria: são sempre
recalculados a partir do orçamento e das metas já cadastrados
(`getBudgetAlerts`/`getGoalAlerts` em `utils/finance.js`), sem persistência
adicional.

## 5. Arquitetura (implementada nesta etapa)

Estrutura atual do `src/`:

```text
src/
├── app/
│   ├── App.jsx
│   ├── routes.jsx
│   └── PreferencesContext.jsx
├── components/
│   ├── layout/
│   ├── ui/
│   ├── charts/
│   └── finance/
├── pages/
│   ├── Dashboard/
│   ├── Transactions/
│   ├── Analytics/
│   ├── Budget/
│   ├── Goals/
│   ├── Cards/
│   ├── Alerts/
│   ├── Settings/
│   └── Help/
├── data/
├── hooks/
├── services/
├── utils/
├── styles/
└── main.jsx
```

`hooks/` contém `useTransactions.js`, `useCategories.js`,
`useAccounts.js`, `useCardPurchases.js`, `useBudget.js`, `useGoals.js`
(estado + CRUD de cada domínio), `useAlerts.js` (selector compartilhado
entre a página `/alertas` e o indicador da Sidebar) e
`useFinanceSummary.js` (selectors aplicados ao mês corrente para o
Dashboard, recebe `categories` e `budget` por parâmetro).
`services/` contém `transactionService.js`, `categoryService.js`,
`accountService.js`, `cardPurchaseService.js`, `budgetService.js`,
`goalService.js`, `preferencesService.js` (CRUD de cada domínio) e
`storageService.js` (wrapper de `localStorage`).
Preferências (`app/PreferencesContext.jsx`) são a única exceção ao padrão
hook-local-por-página: usam React Context porque Sidebar/Header ficam
montadas o tempo todo e precisam refletir mudanças feitas em
`/configuracoes` imediatamente.
`components/finance/` contém os formulários e linhas de listagem de cada
domínio (`TransactionForm`/`TransactionRow`, `CategoryForm`/`CategoryRow`,
`AccountForm`/`AccountRow`, `CardForm`/`CardTile`,
`BudgetCategoryForm`/`BudgetCategoryRow`,
`GoalForm`/`GoalRow`/`GoalContributionForm`). Ao evoluir para as próximas
fases, continuar refatorando por domínio, mantendo a aplicação
funcionando a cada etapa.

## 6. Rotas (implementadas)

- `/` — Dashboard
- `/transacoes` — Transações
- `/analises` — Análises
- `/orcamento` — Orçamento
- `/metas` — Metas
- `/cartoes` — Cartões
- `/alertas` — Alertas
- `/configuracoes` — Configurações
- `/ajuda` — Ajuda

Implementadas com `<Routes>`/`<Route>` do React Router em `app/routes.jsx`
(a leitura de `window.location.pathname` foi removida).

## 7. UI/UX

Referência visual: o mockup mobile fornecido pelo cliente foi usado como inspiração, mas o produto final é **desktop-first**.

Direção:
- sofisticado;
- limpo;
- profissional;
- humano, evitando aparência genérica de dashboard gerado por IA;
- roxo como cor primária;
- superfícies claras;
- sidebar escura;
- microinterações discretas;
- boa hierarquia visual;
- responsividade sem perder a experiência desktop.

Tokens em `src/styles/tokens.css`; `src/styles/index.css` apenas agrega
`tokens.css`, `global.css`, `layout.css`, `components.css`,
`pages/transactions.css`, `pages/cards.css`, `pages/planning.css`
(Orçamento/Metas/Alertas) e as media queries responsivas.

## 8. Regra de qualidade

Antes de finalizar qualquer alteração:
1. verificar imports;
2. executar `npm run build`;
3. verificar rotas;
4. testar estados vazios, loading e erro quando o domínio exigir;
5. não quebrar o Dashboard existente;
6. não criar funcionalidades que movimentem dinheiro real.
