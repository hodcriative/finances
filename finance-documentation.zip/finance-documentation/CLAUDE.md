# Instruções para continuidade — FINANCE

Você está continuando o desenvolvimento de uma plataforma React de organização, análise e planejamento financeiro pessoal.

## 1. Escopo obrigatório

O produto é um **organizador financeiro pessoal**, não um banco e não uma carteira digital.

### NÃO implementar
- pagamentos reais;
- PIX;
- transferências bancárias reais;
- compras reais;
- investimentos reais;
- saque/depósito;
- conexão para movimentação de conta;
- execução de operações em cartão;
- cobrança ou processamento de cartão;
- qualquer integração que permita movimentar dinheiro.

### PODE implementar
- cadastro manual de receitas e despesas;
- contas como registros informativos;
- cartões como registros informativos;
- faturas lançadas/organizadas manualmente;
- orçamento;
- metas;
- categorias;
- análises e gráficos;
- alertas baseados nos dados cadastrados;
- indicadores e insights financeiros;
- autenticação/persistência quando definida a arquitetura de backend.

Sempre use linguagem que deixe claro que os dados são **manuais/representativos** quando houver risco de confusão com movimentação real.

## 2. Estado atual (pós Fase 2)

O código foi migrado da estrutura concentrada em `App.jsx`/`index.css` para a
arquitetura alvo descrita em `docs/02-ARCHITECTURE.md` (`app/`, `components/`,
`pages/`, `data/`, `hooks/`, `services/`, `utils/`, `styles/`).

Implementado nesta etapa:
- Rotas reais com React Router (`app/routes.jsx`), substituindo a leitura de
  `window.location.pathname`;
- Modelo de transação (`data/mockData.js`) e serviço de domínio
  (`services/transactionService.js`) com persistência em `localStorage`
  através de `services/storageService.js`;
- Estado central de transações via hook `hooks/useTransactions.js`
  (create/update/delete);
- Selectors financeiros centralizados em `utils/finance.js`
  (`getTotalIncome`, `getTotalExpenses`, `getBalance`, `getExpensesByCategory`,
  `getMonthlySeries`, `getBudgetUsage`, `getGoalProgress`), consumidos pelo
  hook `hooks/useFinanceSummary.js`;
- Página `/transacoes` completa: listagem, busca por descrição, filtros
  (período, tipo, categoria, conta/cartão), ordenação por data/valor,
  criação, edição e exclusão (com confirmação) de lançamentos, e estado
  vazio explicando o próximo passo;
- Dashboard consumindo os mesmos dados reais das transações: saldo,
  receitas, despesas, economia do mês, gráfico de evolução (6 meses) e
  gastos por categoria são todos derivados dos lançamentos, não mais
  hardcoded;
- Orçamento do mês no Dashboard já deriva a utilização por categoria dos
  lançamentos reais (`getBudgetUsage`); os limites em si continuam sendo
  dados representativos (Fase 4).
- Metas continuam com dados representativos (Fase 4), mas o progresso é
  calculado via `getGoalProgress` em vez de percentual fixo.

Implementado na Fase 3 (domínios de apoio):
- `services/categoryService.js` e `services/accountService.js`, no mesmo
  padrão de `transactionService.js` (CRUD + persistência via
  `storageService.js`);
- `hooks/useCategories.js` e `hooks/useAccounts.js`, no mesmo padrão de
  `useTransactions.js`;
- página `/cartoes` reescrita com três abas — **Cartões** (tiles com
  limite, fatura atual manual, dias de fechamento/vencimento), **Contas**
  (tipo, saldo inicial) e **Categorias** (nome, tipo, ícone, cor) — cada
  uma com criação, edição e desativação (a exclusão física existe nos
  serviços mas a UI usa desativação, para preservar transações já
  lançadas que referenciam o id);
- `TransactionForm`, `Transactions` e `Dashboard` passaram a ler
  categorias/contas dos novos hooks/serviços em vez de importar
  `categories`/`accounts` estaticamente de `data/mockData.js`;
- `data/mockData.js` ganhou os campos representativos de cartão (`brand`,
  `limit`, `currentInvoice`, `closingDay`, `dueDay`, `color`) e de conta
  (`type`, `initialBalance`, `color`), usados como seed inicial do
  `localStorage`.

Ainda são placeholders (usando o componente `components/ui/EmptyState.jsx`):
Configurações e Ajuda.

Implementado na Fase 5 (Análises):
- `utils/finance.js` ganhou `getPeriodComparison`, `getTopExpenses`,
  `getSpendingTrend` e `getCategoryShift`, todos reaproveitando os
  selectors já existentes (`getTotalIncome`/`getTotalExpenses`/
  `getSavingsRate`/`getExpensesByCategory`) em vez de recalcular do zero;
- `hooks/useAnalytics.js`, no mesmo padrão de `useFinanceSummary.js`;
- página `/analises`: seletor de mês, visão geral, evolução de 12 meses
  (reaproveitando `components/charts/FinancialChart.jsx`), distribuição por
  categoria (reaproveitando `components/charts/CategoryDonut.jsx`),
  comparação entre o mês selecionado e qualquer outro mês com lançamentos,
  maiores gastos (reaproveitando `components/finance/TransactionRow.jsx`
  em modo leitura), tendências/insights textuais e exportação em CSV do
  mês selecionado (gerada no navegador, sem backend).

## 3. Próxima prioridade

Com Transações, os domínios de apoio, o planejamento e as Análises no ar,
restam do roadmap:
- Configurações e Ajuda (`/configuracoes`, `/ajuda`) — ainda placeholders,
  RF10 em `docs/03-FUNCTIONAL-REQUIREMENTS.md` já lista o que é esperado
  (nome, moeda, preferências, tema, segurança — como "futuramente"), então
  vale confirmar com o dono do produto o que efetivamente entra agora
  antes de codificar;
- **Fase 6 (Persistência/autenticação)** é a próxima grande etapa do
  roadmap, mas exige decisões de produto/infra antes de qualquer código
  (qual backend, qual banco, estratégia de autenticação) — não começar
  essa fase sem alinhar isso antes;
- Fase 7 (testes, acessibilidade, performance, deploy) vem depois da
  Fase 6.

## 4. Modelo de transação (implementado)

```js
{
  id: "uuid",
  type: "income" | "expense",
  description: "Supermercado",
  amount: 152.40,
  categoryId: "alimentacao",
  accountId: "nubank",
  date: "2026-09-04",
  notes: "Compra semanal",
  createdAt: "...",
  updatedAt: "..."
}
```

O valor deve ser armazenado como número positivo; o campo `type` determina se é receita ou despesa. Não armazenar despesa como número negativo na camada de domínio.

## 4.1 Modelo de conta/cartão/categoria (implementado na Fase 3)

Contas e cartões continuam na mesma coleção (`services/accountService.js`,
chave `accounts` no `localStorage`), diferenciados por `kind`:

```js
// conta
{ id, kind: "account", name, type: "checking"|"savings"|"cash"|"other", initialBalance, color, active }

// cartão representativo
{ id, kind: "card", name, brand, limit, currentInvoice, closingDay, dueDay, color, active }
```

`currentInvoice` é a fatura atual, informada e atualizada manualmente pelo
usuário — nunca calculada a partir de movimentações reais do cartão.

Categorias (`services/categoryService.js`, chave `categories`):

```js
{ id, name, type: "income"|"expense"|"both", icon, color, active }
```

Exclusão de qualquer um dos três domínios é feita por **desativação**
(`active: false`) na UI, para não quebrar transações já lançadas que
referenciam o id; os serviços também expõem `remove()` para exclusão
física, mas a UI não a utiliza hoje.

## 4.2 Modelo de orçamento/meta (implementado na Fase 4)

Orçamento (`services/budgetService.js`, chave `budgets` — um registro por
mês):

```js
{ id, month: "2026-09", totalLimit, categories: [{ categoryId, limit }] }
```

`totalLimit` e cada `limit` por categoria são valores de referência
definidos pelo usuário na página `/orcamento`; a *utilização* continua
sendo sempre calculada a partir das despesas reais (`getBudgetUsage`,
`utils/finance.js`), nunca armazenada.

Metas (`services/goalService.js`, chave `goals`):

```js
{ id, title, targetAmount, currentAmount, deadline, icon, color, status: "active"|"paused"|"completed" }
```

Aporte (`addContribution`) apenas soma ao `currentAmount` já acumulado —
é sempre um registro/planejamento manual, nunca uma transferência real
entre contas ou cartões. O status muda para `"completed"` automaticamente
quando `currentAmount` atinge `targetAmount` (a não ser que a meta esteja
`"paused"`). Como nenhuma transação referencia uma meta, a exclusão em
`goalService.remove()` é física.

Alertas (`/alertas`) não têm serviço/coleção própria: são sempre
recalculados a partir do orçamento e das metas já cadastrados
(`getBudgetAlerts`/`getGoalAlerts` em `utils/finance.js`), sem persistência
adicional.

## 5. Arquitetura (implementada nesta etapa)

Estrutura atual do `src/`:

```text
src/
├── app/
│   ├── App.jsx
│   └── routes.jsx
├── components/
│   ├── layout/
│   ├── ui/
│   ├── charts/
│   └── finance/
├── pages/
│   ├── Dashboard/
│   ├── Transactions/
│   ├── Analytics/
│   ├── Budget/
│   ├── Goals/
│   ├── Cards/
│   ├── Alerts/
│   ├── Settings/
│   └── Help/
├── data/
├── hooks/
├── services/
├── utils/
├── styles/
└── main.jsx
```

`hooks/` contém `useTransactions.js`, `useCategories.js`,
`useAccounts.js`, `useBudget.js` e `useGoals.js` (estado + CRUD de cada
domínio) e `useFinanceSummary.js` (selectors aplicados ao mês corrente
para o Dashboard, recebe `categories` e `budget` por parâmetro).
`services/` contém `transactionService.js`, `categoryService.js`,
`accountService.js`, `budgetService.js`, `goalService.js` (CRUD de cada
domínio) e `storageService.js` (wrapper de `localStorage`).
`components/finance/` contém os formulários e linhas de listagem de cada
domínio (`TransactionForm`/`TransactionRow`, `CategoryForm`/`CategoryRow`,
`AccountForm`/`AccountRow`, `CardForm`/`CardTile`,
`BudgetCategoryForm`/`BudgetCategoryRow`,
`GoalForm`/`GoalRow`/`GoalContributionForm`). Ao evoluir para as próximas
fases, continuar refatorando por domínio, mantendo a aplicação
funcionando a cada etapa.

## 6. Rotas (implementadas)

- `/` — Dashboard
- `/transacoes` — Transações
- `/analises` — Análises
- `/orcamento` — Orçamento
- `/metas` — Metas
- `/cartoes` — Cartões
- `/alertas` — Alertas
- `/configuracoes` — Configurações
- `/ajuda` — Ajuda

Implementadas com `<Routes>`/`<Route>` do React Router em `app/routes.jsx`
(a leitura de `window.location.pathname` foi removida).

## 7. UI/UX

Referência visual: o mockup mobile fornecido pelo cliente foi usado como inspiração, mas o produto final é **desktop-first**.

Direção:
- sofisticado;
- limpo;
- profissional;
- humano, evitando aparência genérica de dashboard gerado por IA;
- roxo como cor primária;
- superfícies claras;
- sidebar escura;
- microinterações discretas;
- boa hierarquia visual;
- responsividade sem perder a experiência desktop.

Tokens em `src/styles/tokens.css`; `src/styles/index.css` apenas agrega
`tokens.css`, `global.css`, `layout.css`, `components.css`,
`pages/transactions.css`, `pages/cards.css`, `pages/planning.css`
(Orçamento/Metas/Alertas) e as media queries responsivas.

## 8. Regra de qualidade

Antes de finalizar qualquer alteração:
1. verificar imports;
2. executar `npm run build`;
3. verificar rotas;
4. testar estados vazios, loading e erro quando o domínio exigir;
5. não quebrar o Dashboard existente;
6. não criar funcionalidades que movimentem dinheiro real.
