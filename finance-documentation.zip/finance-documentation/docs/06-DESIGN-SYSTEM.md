# 06 — Design System

## Referência

O mockup original era um aplicativo mobile. A decisão do projeto é transformá-lo em uma experiência desktop-first.

## Paleta atual

| Token | Valor | Uso |
|---|---|---|
| `--primary` | `#6c5ce7` | ações e destaque |
| `--primary-dark` | `#5844ca` | hover |
| `--primary-soft` | `#f0edff` | fundos suaves |
| `--success` | `#00a878` | receitas/sucesso |
| `--danger` | `#ef5b63` | despesas/erro |
| `--warning` | `#f2a93b` | atenção |
| `--bg` | `#f5f6fa` | fundo |
| `--surface` | `#ffffff` | cards |
| `--text` | `#202333` | texto |
| `--muted` | `#858a9a` | texto secundário |
| `--border` | `#e8e9ef` | bordas |
| `--sidebar` | `#10141c` | navegação |

## Tipografia

O CSS atual usa a pilha Inter/system-ui. A referência visual usa tipografia compacta e moderna.

## Componentes visuais

- Sidebar escura;
- navegação com estado ativo roxo;
- cards brancos com borda sutil;
- card de saldo em gradiente roxo;
- botões primários roxos;
- badges e indicadores discretos;
- gráficos leves;
- modal com backdrop e blur.

## Princípios UX

1. números importantes devem ter hierarquia forte;
2. receitas e despesas devem ser visualmente distinguíveis;
3. ações primárias devem ser fáceis de encontrar;
4. não exagerar em sombras/gradientes;
5. estados vazios devem explicar o próximo passo;
6. formulários devem mostrar validação próxima ao campo;
7. acessibilidade de teclado e foco deve ser preservada.
