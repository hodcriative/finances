# 12 — Comandos de desenvolvimento

```bash
npm install
npm run dev
npm run build
npm run preview
```

## Windows PowerShell

Servidor:

```powershell
npm run dev
```

Build de validação:

```powershell
npm run build
```

Se houver mudança em dependências, executar `npm install`.

`node_modules` e `dist` não devem ser versionados no handoff/fonte.

## Publicar no GitHub Pages

O deploy é automático via GitHub Actions (`.github/workflows/deploy.yml`), sem precisar de branch `gh-pages` nem instalar nada localmente:

1. Suba o projeto para um repositório no GitHub (`git init`, `git remote add origin ...`, `git push`), na branch `main`.
2. No repositório, vá em **Settings → Pages** e, em "Build and deployment → Source", selecione **GitHub Actions** (não "Deploy from a branch").
3. Qualquer push na branch `main` dispara o workflow (build + deploy automático); ele também pode ser rodado manualmente pela aba **Actions** ("Run workflow").
4. A URL final aparece na aba **Actions**, no job `deploy` (e depois em Settings → Pages), no formato `https://usuario.github.io/nome-do-repo/`.

Duas decisões técnicas por trás disso, caso precise mexer:
- `vite.config.js` calcula o `base` automaticamente a partir de `GITHUB_REPOSITORY` (variável que o GitHub Actions já define sozinho) — não precisa editar nada manualmente ao trocar o nome do repositório.
- `main.jsx` usa `HashRouter` (não `BrowserRouter`): GitHub Pages é hospedagem estática pura, sem rewrite de servidor para SPA, então recarregar uma rota interna (ex.: `/transacoes`) daria 404 com `BrowserRouter`. Com `HashRouter` as URLs ficam com `#` (ex.: `.../repo/#/transacoes`), mas todas as rotas funcionam normalmente, inclusive com F5.
