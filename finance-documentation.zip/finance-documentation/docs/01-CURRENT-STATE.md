# 01 — Estado atual

## Funcionando

- React/Vite/React Router com rotas reais (`app/routes.jsx`), sem depender de `window.location.pathname`;
- build de produção validado (`npm run build`);
- Dashboard desktop conectado a dados reais de transações (não mais mock hardcoded);
- Sidebar recolhível, com `NavLink` apontando para as rotas reais;
- cards financeiros (saldo, receitas, despesas, economia) derivados dos lançamentos do mês selecionado, com seletor de mês no Dashboard (setas anterior/próximo + atalho "voltar para o mês atual"), padrão: mês corrente;
- gráfico de evolução (6 meses) e donut de gastos por categoria, ambos derivados de `utils/finance.js`;
- página `/transacoes` completa: lista, busca por descrição, filtros (período/tipo/categoria/conta), ordenação por data/valor, criação, edição e exclusão (com confirmação);
- modal de novo/editar lançamento com validação de formulário (valor > 0, descrição obrigatória, categoria compatível com o tipo, data obrigatória);
- persistência em `localStorage` via `services/storageService.js` + `services/transactionService.js`, sobrevive a reload da página;
- resumo de orçamento no Dashboard com utilização derivada das despesas reais por categoria (`getBudgetUsage`);
- resumo de metas com progresso calculado (`getGoalProgress`), embora os valores das metas ainda sejam representativos;
- domínios de Categorias e Contas/Cartões com CRUD próprio (`services/categoryService.js`, `services/accountService.js`, `hooks/useCategories.js`, `hooks/useAccounts.js`), persistidos em `localStorage`, seguindo o mesmo padrão do domínio de Transações;
- página `/cartoes` com quatro abas — **Cartões** (tiles com limite, fatura atual e total mensal de compras parceladas informados manualmente, dias de fechamento/vencimento), **Compras** (compras parceladas por cartão: descrição, valor mensal, número de parcelas, total derivado), **Contas** (tipo, saldo inicial) e **Categorias** (nome, tipo, ícone, cor) — cada uma com criação, edição e desativação (Compras usa exclusão física, sem transações referenciando);
- `TransactionForm`, `Transactions` e `Dashboard` já leem categorias/contas dos novos serviços em vez de `data/mockData.js` estático;
- página `/orcamento` com gestão completa: limite geral do mês (definir/editar) e limites por categoria (criar, editar, remover), com destaque visual quando o gasto ultrapassa o limite (`services/budgetService.js`, `hooks/useBudget.js`);
- página `/metas` com gestão completa: criar, editar e excluir metas, registrar aporte (sempre um ajuste manual do valor guardado, nunca uma transferência real), pausar/retomar e destaque visual de meta concluída (`services/goalService.js`, `hooks/useGoals.js`);
- página `/alertas` com alertas calculados a partir do orçamento e das metas cadastrados (limite geral/por categoria excedido, meta concluída, meta perto do prazo) — nada é armazenado à parte, tudo é recalculado a cada acesso (`utils/finance.js`: `getBudgetAlerts`, `getGoalAlerts`);
- Dashboard passou a ler orçamento e metas reais via `hooks/useBudget.js`/`hooks/useGoals.js` em vez dos dados estáticos de `data/mockData.js`.

## Ainda é mock/protótipo

- "Fatura manual" do cartão hoje é um único valor atual editável (`currentInvoice`), mais o total mensal derivado das compras parceladas lançadas na aba Compras — ainda sem histórico de faturas por mês/lançamentos individuais na fatura;
- Alertas são sempre computados on-the-fly (sem persistência própria, sem campo `read`) — se no futuro fizer sentido marcar alertas como lidos/ocultos, isso exigirá um `alertService.js` próprio;
- dentro de Configurações, moeda, primeiro dia do mês financeiro e segurança/login continuam pendentes (ver seção "Configurações e Ajuda" abaixo);
- tema escuro cobre as superfícies principais (fundo, painéis, texto, bordas), mas não retoca os fundos claros de estados de severidade (linha de orçamento excedido/próximo do limite, badges de alerta).

## Domínios de apoio (Fase 3 — implementado)

- Categorias, Contas e Cartões passaram de dados estáticos para domínios com CRUD (criar, editar, desativar/excluir), seguindo o padrão de `services/`+`hooks/` já usado em Transações;
- exclusão de categoria/conta/cartão com lançamentos vinculados é feita por **desativação** (`active: false`), preservando o histórico das transações já lançadas — a opção de exclusão física também existe nos serviços (`remove`), mas não é usada pela UI para não quebrar referências;
- contas e cartões continuam representados na mesma coleção (`kind: "account" | "card"`), como já vinha no modelo original de `data/mockData.js`.

## Planejamento (Fase 4 — implementado nesta etapa)

- `services/budgetService.js`: orçamento por mês (`month`, `totalLimit`, `categories: [{ categoryId, limit }]`), com `ensureMonth`, `setTotalLimit`, `setCategoryLimit` e `removeCategoryLimit`, persistidos em `localStorage` (chave `budgets`) no mesmo padrão de `categoryService.js`;
- `services/goalService.js`: CRUD de metas (`create`, `update`, `remove`) mais `addContribution` (aporte) e `setStatus` (pausar/retomar), persistidos em `localStorage` (chave `goals`); como nenhuma transação referencia uma meta, a exclusão é física;
- `hooks/useBudget.js` e `hooks/useGoals.js`, no mesmo padrão de `useCategories.js`/`useAccounts.js`;
- `utils/finance.js` ganhou `getBudgetAlerts` e `getGoalAlerts`, consumidos pela página `/alertas`;
- `hooks/useFinanceSummary.js` passou a receber `budget` por parâmetro (antes importava o mock estático diretamente).

## Análises (Fase 5 — implementado nesta etapa)

- `utils/finance.js` ganhou os selectors `getPeriodComparison` (compara dois meses quaisquer usando os mesmos totais do Dashboard), `getTopExpenses` (maiores despesas do período), `getSpendingTrend` (direção da despesa média ao longo da série mensal) e `getCategoryShift` (categoria com maior variação entre dois períodos) — todos reaproveitando `getTotalIncome`/`getTotalExpenses`/`getSavingsRate`/`getExpensesByCategory` já existentes, sem duplicar cálculo;
- `hooks/useAnalytics.js`, no mesmo padrão de `useFinanceSummary.js`, agrega tudo isso para a página;
- página `/analises` com: seletor de mês (mesmo padrão de Dashboard/Orçamento), visão geral (saldo/receitas/despesas/economia), evolução dos últimos 12 meses (reaproveitando `FinancialChart`), distribuição por categoria (reaproveitando `CategoryDonut`), comparação entre o mês selecionado e qualquer outro mês com lançamentos, maiores gastos do mês, tendências/insights textuais e exportação em CSV do mês selecionado (client-side, sem backend).

## Compras parceladas por cartão (adicionado após a Fase 3)

- `services/cardPurchaseService.js` (chave `cardPurchases`) e `hooks/useCardPurchases.js`, no mesmo padrão dos demais domínios;
- aba **Compras** em `/cartoes`: lançamento de compras parceladas por cartão (descrição, valor mensal, número de parcelas), com total da compra e total mensal comprometido por cartão sempre derivados (`getPurchaseTotal`/`getCardPurchasesSummary` em `utils/finance.js`), nunca armazenados separadamente;
- o tile do cartão em `/cartoes` passou a exibir o total mensal das compras parceladas daquele cartão.

## Configurações e Ajuda (implementado após confirmação do usuário para priorizar antes da Fase 6)

- `services/preferencesService.js` (chave `preferences`, registro único: nome, tema, preferências de notificação) e `app/PreferencesContext.jsx` (Context, não hook local — Sidebar/Header ficam sempre montadas e precisam refletir mudanças em tempo real);
- `hooks/useAlerts.js`: lógica de alertas extraída da página `/alertas` para ser reaproveitada pelo indicador de notificações da Sidebar, respeitando as preferências de quais tipos de alerta mostrar;
- página `/configuracoes`: nome (com validação), tema claro/escuro e checkboxes de notificação (orçamento/metas) aplicados imediatamente; seção "Em definição" documentando moeda, primeiro dia do mês financeiro e segurança/login como pendentes (dependem de decisões de produto/infra ou de mudanças mais amplas no app);
- página `/ajuda`: FAQ estático explicando o funcionamento de cada domínio já implementado;
- tema escuro via `[data-theme="dark"]` em `styles/tokens.css`, cobrindo fundo, painéis, texto, bordas e o novo token `--surface-alt` (chips/inputs sobre painéis); estados de severidade (alerta, orçamento excedido) não foram retocados nesta etapa.

## Backend/API (Fase 6 — em andamento)

- `server/` (Node.js + Express + SQLite via `node:sqlite`, sem dependência externa) implementa a API completa: autenticação por e-mail/senha com JWT (`bcryptjs` + `jsonwebtoken`), e CRUD de todos os domínios (preferências, categorias, contas/cartões, compras parceladas, transações, orçamento, metas), cada um filtrado por usuário — ver `server/README.md` para rotas e como rodar;
- schema SQLite espelha `docs/04-DATA-MODEL.md` e as regras que já existiam nos `services/*.js` do frontend (aporte de meta só soma, nunca transfere; total de compra parcelada sempre derivado; etc.);
- testado manualmente via curl: registro/login, token ausente/inválido, CRUD completo em cada domínio, isolamento entre usuários (um usuário não lê/edita/lança nada no que pertence a outro);
- **o frontend (`src/`) ainda não chama essa API** — continua 100% em `localStorage`, sem login. Integrar (trocar `services/*.js` para `fetch`, telas de login/registro, proteção de rotas) é o próximo passo, ainda não iniciado. Combinado: sem migração automática dos dados que já existem no `localStorage`.

## Limitações técnicas atuais

- backend existe (`server/`, ver acima) mas o frontend ainda não está integrado a ele — hoje continua tudo local via `localStorage`, incluindo nome/tema/preferências de notificação (sem login, sem sincronização entre dispositivos);
- não há testes automatizados;
- não há paginação/virtualização na lista de transações (aceitável para o volume atual de dados de protótipo);
- filtro de período na tela de Transações é limitado a "este mês/mês passado/todos", sem seletor de intervalo livre.

## Correção de build/runtime

O handoff inclui `vite.config.js` com `@vitejs/plugin-react`. Isso é importante para o processamento correto de JSX no Vite e evita o problema de runtime `React is not defined` observado anteriormente.

Observação de ambiente: em instalações onde `node_modules` foi copiado de outra máquina, pode faltar o binário nativo opcional do Rollup (`@rollup/rollup-linux-x64-gnu` ou equivalente da plataforma). Se `npm run build` falhar com "Cannot find module @rollup/rollup-...", rode `npm install` novamente (ou remova `node_modules`/`package-lock.json` e reinstale) para que o binário correto seja baixado.

