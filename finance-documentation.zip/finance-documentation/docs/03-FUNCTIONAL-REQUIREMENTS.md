# 03 — Requisitos funcionais

## RF01 — Dashboard

Exibir:
- saldo disponível calculado a partir dos dados registrados;
- total de receitas no período;
- total de despesas no período;
- economia do período;
- evolução mensal;
- gastos por categoria;
- transações recentes;
- resumo de orçamento;
- resumo de metas;
- insights derivados dos dados.

## RF02 — Transações

O usuário deve conseguir:
- listar lançamentos;
- pesquisar;
- filtrar por tipo;
- filtrar por categoria;
- filtrar por conta/cartão;
- filtrar por período;
- criar receita;
- criar despesa;
- editar lançamento;
- excluir lançamento;
- visualizar detalhes.

### Campos
- tipo: receita/despesa;
- valor;
- descrição;
- categoria;
- conta/cartão representado;
- data;
- observação opcional.

## RF03 — Categorias

Permitir categorias padrão e, futuramente, categorias personalizadas.

## RF04 — Contas

Permitir registrar contas para classificação dos lançamentos. Não conectar para movimentação.

## RF05 — Orçamento

Permitir definir limite mensal geral e/ou por categoria.

Indicadores:
- limite;
- utilizado;
- restante;
- percentual;
- situação: normal, atenção, excedido.

## RF06 — Metas

Permitir:
- nome;
- valor-alvo;
- valor acumulado;
- prazo;
- categoria opcional;
- progresso;
- status.

O usuário registra aportes manualmente; não existe transferência automática para uma meta.

## RF07 — Cartões

Permitir registrar:
- nome;
- bandeira;
- limite;
- fechamento;
- vencimento;
- valor de fatura informado/calculado pelos lançamentos associados.

Cartões são apenas controle. Nenhuma compra ou pagamento real é executado.

## RF08 — Análises

Exibir:
- receitas x despesas;
- evolução temporal;
- distribuição por categoria;
- comparação entre períodos;
- maiores gastos;
- taxa de economia;
- tendências e insights.

## RF09 — Alertas

Alertas internos baseados em regras, por exemplo:
- orçamento próximo do limite;
- orçamento excedido;
- meta sem progresso;
- fatura próxima do vencimento (informativo);
- comportamento de gasto fora do padrão.

## RF10 — Perfil/configurações

Futuramente:
- nome;
- moeda;
- primeiro dia do mês financeiro, se necessário;
- preferências de notificações;
- tema;
- segurança.
