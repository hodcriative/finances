# 00 — Visão geral do projeto

## Objetivo

O FINANCE é uma plataforma de organização, análise e planejamento financeiro pessoal. O usuário registra manualmente sua realidade financeira e usa a plataforma para entender hábitos, acompanhar orçamento, estabelecer metas e tomar decisões melhores.

## Proposta de valor

Transformar registros financeiros manuais em uma visão clara de:
- quanto entrou;
- quanto saiu;
- onde o dinheiro foi gasto;
- quanto foi economizado;
- quanto do orçamento já foi usado;
- quais metas estão avançando;
- quais comportamentos merecem atenção.

## Limite de produto

A aplicação não é uma instituição financeira, não é um gateway de pagamento e não é uma carteira digital.

### Contas
Representam contas financeiras cadastradas pelo usuário para organização. Não são acessadas para movimentação.

### Cartões
Representam cartões cadastrados pelo usuário. Limite, utilizado, disponível e fatura são dados organizacionais e podem ser preenchidos/atualizados manualmente.

### Transações
São lançamentos manuais. Uma transação não dispara nenhuma operação externa.

## Público

Pessoa que deseja organizar sua vida financeira sem depender de automações bancárias, priorizando controle, visualização e planejamento.
