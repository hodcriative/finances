# 09 — Critérios de aceite

## Transações

- [x] Criar uma receita altera os totais corretamente.
- [x] Criar uma despesa altera os totais corretamente.
- [x] Editar um lançamento recalcula os indicadores.
- [x] Excluir um lançamento recalcula os indicadores.
- [x] Filtro por período funciona.
- [x] Filtro por categoria funciona.
- [x] Busca textual funciona.
- [x] Valores aparecem em BRL.
- [x] Valor inválido impede salvamento.

## Dashboard

- [x] Saldo é derivado dos dados e não hardcoded.
- [x] Receita e despesa refletem o período selecionado.
- [x] Gráficos refletem os lançamentos.
- [x] Gastos por categoria refletem os lançamentos.
- [x] Transações recentes refletem os dados reais da aplicação.

## Orçamento

- [x] Utilização é derivada das despesas (`getBudgetUsage`).
- [x] Percentual não produz valores inválidos.
- [x] Excedente é identificado, com destaque visual (borda/fundo vermelho e selo "Limite excedido") tanto no limite geral quanto por categoria.
- [x] Limite geral e limites por categoria podem ser criados, editados e removidos por mês (`services/budgetService.js`, página `/orcamento`).

## Metas

- [x] Progresso é calculado corretamente (`getGoalProgress`).
- [x] Meta concluída é identificada visualmente (selo "Concluída" e destaque no card, status muda automaticamente ao atingir o valor-alvo).
- [x] Aporte é tratado como registro/planejamento, nunca como transferência real (`goalService.addContribution` apenas soma ao valor guardado).
- [x] Metas podem ser criadas, editadas, pausadas/retomadas e excluídas (página `/metas`).

## Alertas

- [x] Alerta é exibido quando o limite geral ou de uma categoria é excedido, ou está perto do limite (≥ 80%, situação "atenção" do RF05).
- [x] Alerta é exibido quando uma meta é concluída.
- [x] Alerta é exibido quando uma meta ativa está a 30 dias ou menos do prazo e ainda não foi concluída.
- [x] Nenhum alerta é persistido separadamente — todos são recalculados a partir do orçamento e das metas já cadastrados.

## Cartões

- [x] Limite é apenas informativo.
- [x] Fatura é manual (campo `currentInvoice`, editado pelo usuário no formulário do cartão).
- [x] Nenhuma ação externa é executada.
- [x] Compra parcelada lançada na aba Compras soma corretamente ao total mensal exibido no tile do cartão (`getCardPurchasesSummary`).
- [x] Total da compra (`installmentAmount × installments`) é sempre calculado, nunca digitado diretamente pelo usuário.
- [x] Excluir uma compra parcelada recalcula o total mensal do cartão imediatamente.

## Contas

- [x] Conta é um registro informativo (nome, tipo, saldo inicial), sem conexão bancária.
- [x] Desativar uma conta não apaga o histórico de transações já lançadas nela.

## Categorias

- [x] Categoria pode ser criada, editada e desativada.
- [x] Categoria compatível com o tipo (receita/despesa/ambos) é validada no formulário de transação.
- [x] Desativar uma categoria não apaga o histórico de transações já lançadas com ela.

## Análises

- [x] Todos os números exibidos são calculados a partir dos lançamentos reais, sem valores fixos/estimados.
- [x] Comparação entre períodos funciona com qualquer par de meses que tenha lançamentos, não só mês atual vs. anterior.
- [x] Exportação em CSV reflete exatamente os lançamentos do mês selecionado na tela.

## Configurações e Ajuda

- [x] Alterar o nome em Configurações atualiza a Sidebar e o Header imediatamente, sem precisar recarregar a página.
- [x] Alternar o tema aplica claro/escuro em toda a aplicação sem recarregar (via `data-theme` em `tokens.css`).
- [x] Desmarcar "alertas de orçamento" ou "alertas de metas" oculta esses alertas tanto na página `/alertas` quanto no indicador de notificações da Sidebar.
- [x] O indicador de notificações da Sidebar reflete a contagem real de alertas (não um valor fixo).
- [x] Preferências persistem após recarregar a página (via `localStorage`, chave `preferences`).
- [x] Nome vazio é bloqueado no formulário de perfil, com mensagem de erro.
- [ ] Moeda, primeiro dia do mês financeiro e segurança/login — deliberadamente não implementados; documentados como pendentes na própria página `/configuracoes` (RF10 "futuramente").

## Backend/API (Fase 6)

- [x] Nenhuma rota de domínio responde sem um token válido (`requireAuth` em todas exceto `/api/auth/*`).
- [x] Cada usuário só lê, edita e exclui os próprios dados — verificado manualmente com dois usuários (contas/cartões, compras parceladas, transações, orçamento, metas).
- [x] Senha nunca é armazenada em texto puro (hash `bcryptjs`).
- [x] Registro cria automaticamente as mesmas categorias padrão do seed atual do `localStorage`.
- [x] Aporte de meta via API só soma ao valor acumulado — nunca transfere entre contas/cartões (mesma regra do frontend).
- [x] Total de compra parcelada e total mensal por cartão são sempre derivados no backend, nunca aceitos como campo digitado.
- [x] Servidor recusa subir com `JWT_SECRET` ausente, igual ao placeholder de exemplo, ou curto demais.
- [x] Rate limit em `/api/auth/*` bloqueia após 20 tentativas em 15 minutos (testado manualmente).
- [x] `npm audit` sem vulnerabilidades conhecidas nas dependências do servidor.
- [x] `POST /api/auth/logout` revoga a sessão do token em uso, sem afetar outras sessões ativas do mesmo usuário (testado com múltiplas sessões simultâneas).
- [x] `POST /api/auth/logout-all` revoga todas as sessões do usuário de uma vez.
- [ ] HTTPS e verificação de e-mail — deliberadamente fora do escopo desta etapa (ver "Segurança" em `server/README.md`); necessários antes de expor a API fora de `localhost`.
- [ ] Frontend consumindo a API (ainda não integrado — ver `docs/01-CURRENT-STATE.md`).

## Produto

- [x] Não existe botão que efetue pagamento.
- [x] Não existe integração que movimente dinheiro.
- [x] Não existe integração para controlar cartão externamente.
