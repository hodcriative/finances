# 07 — Rotas e páginas

| Rota | Página | Estado |
|---|---|---|
| `/` | Dashboard | funcional, dados reais |
| `/dashboard` | Dashboard | funcional, dados reais |
| `/transacoes` | Transações | funcional (CRUD completo) |
| `/analises` | Análises | placeholder |
| `/orcamento` | Orçamento | placeholder (utilização já calculada no Dashboard) |
| `/metas` | Metas | placeholder (progresso já calculado no Dashboard) |
| `/cartoes` | Cartões | placeholder |
| `/alertas` | Alertas | placeholder |
| `/configuracoes` | Configurações | placeholder |
| `/ajuda` | Central de ajuda | placeholder |

## Refatoração (concluída)

A lógica baseada em `window.location.pathname` foi substituída por rotas
declarativas do React Router em `src/app/routes.jsx`:

```jsx
<Routes>
  <Route path="/" element={<Dashboard />} />
  <Route path="/transacoes" element={<Transactions />} />
  ...
</Routes>
```

