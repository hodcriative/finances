# 04 — Modelo de dados

O modelo abaixo é a proposta inicial. Pode ser adaptado quando a persistência/backend forem definidos.

## User

```js
{
  id,
  name,
  email,
  avatarUrl,
  createdAt,
  updatedAt
}
```

## Account

```js
{
  id,
  userId,
  name,
  type: "checking" | "savings" | "cash" | "other",
  initialBalance,
  color,
  active,
  createdAt,
  updatedAt
}
```

`Account` é uma representação para organização. Não possui credenciais bancárias nem conexão de movimentação.

## Card

```js
{
  id,
  userId,
  name,
  brand,
  limit,
  closingDay,
  dueDay,
  color,
  active,
  createdAt,
  updatedAt
}
```

## Category

```js
{
  id,
  userId: null | string,
  name,
  type: "income" | "expense" | "both",
  icon,
  color,
  active
}
```

## Transaction

```js
{
  id,
  userId,
  type: "income" | "expense",
  amount,
  description,
  categoryId,
  accountId: null | string,
  cardId: null | string,
  date,
  notes,
  createdAt,
  updatedAt
}
```

### Regra
`amount` deve ser sempre positivo. O tipo define a natureza do lançamento.

## Budget

```js
{
  id,
  userId,
  month: "2026-09",
  totalLimit,
  categories: [
    { categoryId, limit }
  ]
}
```

## Goal

```js
{
  id,
  userId,
  title,
  targetAmount,
  currentAmount,
  deadline,
  icon,
  color,
  status: "active" | "completed" | "paused"
}
```

## Alert

```js
{
  id,
  userId,
  type,
  title,
  message,
  severity,
  read,
  createdAt
}
```

## Relações

```text
User
 ├── Accounts
 ├── Cards
 ├── Categories
 ├── Transactions
 ├── Budgets
 ├── Goals
 └── Alerts

Transaction
 ├── Category
 ├── Account (opcional)
 └── Card (opcional)
```
