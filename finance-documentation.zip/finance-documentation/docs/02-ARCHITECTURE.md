# 02 — Arquitetura proposta

## Camadas

```text
UI / Pages
   ↓
Components
   ↓
Hooks / Application state
   ↓
Domain rules / selectors
   ↓
Services / repositories
   ↓
Persistence (futuro)
```

## Estrutura alvo

```text
src/
├── app/
│   ├── App.jsx
│   └── routes.jsx
├── components/
│   ├── layout/
│   │   ├── Sidebar.jsx
│   │   └── Header.jsx
│   ├── ui/
│   │   ├── Button.jsx
│   │   ├── Modal.jsx
│   │   ├── Select.jsx
│   │   ├── Input.jsx
│   │   ├── EmptyState.jsx
│   │   └── ProgressBar.jsx
│   ├── charts/
│   │   ├── FinancialChart.jsx
│   │   └── CategoryDonut.jsx
│   └── finance/
│       ├── TransactionRow.jsx
│       ├── TransactionForm.jsx
│       ├── BudgetProgress.jsx
│       └── GoalProgress.jsx
├── pages/
│   ├── Dashboard/
│   ├── Transactions/
│   ├── Analytics/
│   ├── Budget/
│   ├── Goals/
│   ├── Cards/
│   ├── Alerts/
│   ├── Settings/
│   └── Help/
├── data/
│   └── mockData.js
├── hooks/
│   ├── useTransactions.js
│   └── useFinanceSummary.js
├── services/
│   ├── transactionService.js
│   └── storageService.js
├── utils/
│   ├── currency.js
│   ├── dates.js
│   └── finance.js
├── styles/
│   ├── tokens.css
│   ├── global.css
│   ├── layout.css
│   ├── components.css
│   └── pages/
└── main.jsx
```

## Princípio de domínio

A UI não deve recalcular regras financeiras de maneira independente em cada página. Criar selectors/helpers centralizados.

Exemplos:

```js
getTotalIncome(transactions, period)
getTotalExpenses(transactions, period)
getBalance(transactions, initialBalance)
getExpensesByCategory(transactions, period)
getBudgetUsage(budget, transactions, period)
getGoalProgress(goal)
```

Isso garante que Dashboard, Transações e Análises mostrem números consistentes.
