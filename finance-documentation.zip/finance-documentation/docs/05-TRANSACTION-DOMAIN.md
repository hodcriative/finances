# 05 — Domínio de Transações

## Objetivo

Este é o módulo central do Finance. A maioria dos indicadores será derivada dos lançamentos.

## Fluxo de criação

```text
Nova transação
    ↓
Escolher Receita/Despesa
    ↓
Informar valor
    ↓
Descrição
    ↓
Categoria
    ↓
Conta ou cartão representado
    ↓
Data
    ↓
Observação opcional
    ↓
Validar
    ↓
Salvar
    ↓
Atualizar estado
    ↓
Recalcular Dashboard/Análises/Orçamento
```

## Validações

- tipo obrigatório;
- valor maior que zero;
- categoria compatível com o tipo;
- data válida;
- descrição obrigatória ou opcional conforme decisão final de UX;
- conta/cartão opcional quando a regra de negócio permitir.

## Edição

Ao editar, atualizar somente o lançamento e recalcular todos os selectors derivados.

## Exclusão

Preferir confirmação antes de excluir.

## Filtros

Filtros previstos:
- período;
- tipo;
- categoria;
- conta;
- cartão;
- texto livre.

## Persistência inicial recomendada

Para prototipagem sem backend, usar `localStorage` por usuário/local, encapsulado em um serviço:

```text
services/storageService.js
```

Não acessar `localStorage` diretamente em dezenas de componentes.

## Persistência futura

Quando houver backend, trocar a implementação do repository/service sem alterar as páginas.
