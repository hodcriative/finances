# 10 — Prompt de continuidade para Claude

Você é o desenvolvedor responsável por continuar o projeto FINANCE.

Leia primeiro:
1. `CLAUDE.md`
2. `docs/00-PROJECT-OVERVIEW.md`
3. `docs/01-CURRENT-STATE.md`
4. `docs/02-ARCHITECTURE.md`
5. `docs/03-FUNCTIONAL-REQUIREMENTS.md`
6. `docs/04-DATA-MODEL.md`
7. `docs/05-TRANSACTION-DOMAIN.md`
8. `docs/06-DESIGN-SYSTEM.md`
9. `docs/07-ROUTES.md`
10. `docs/08-ROADMAP.md`
11. `docs/09-ACCEPTANCE-CRITERIA.md`

## Contexto

O FINANCE é uma plataforma de organização, análise e planejamento financeiro pessoal. O usuário registra manualmente receitas, despesas, contas, cartões, orçamento e metas.

**Regra inegociável:** o sistema não movimenta dinheiro real e não movimenta cartões. Não implementar pagamentos, PIX, transferências, investimentos, compras ou integrações de movimentação bancária/cartão.

## Estado atual

Dashboard, Transações (`/transacoes`), os domínios de apoio (Categorias, Contas, Cartões — `/cartoes`), o planejamento (Orçamento `/orcamento`, Metas `/metas`, Alertas `/alertas`) e Análises (`/analises`) já estão funcionais com dados reais, persistidos em `localStorage`. Configurações e Ajuda ainda são placeholders. O código segue a arquitetura alvo (`src/app`, `src/components`, `src/pages`, `src/data`, `src/hooks`, `src/services`, `src/utils`, `src/styles`).

Concluído na Fase 5:
- `utils/finance.js` ganhou `getPeriodComparison`, `getTopExpenses`, `getSpendingTrend` e `getCategoryShift`, reaproveitando os selectors já existentes;
- `hooks/useAnalytics.js`, no mesmo padrão de `useFinanceSummary.js`;
- página `/analises` completa: seletor de mês, visão geral, evolução de 12 meses, distribuição por categoria, comparação entre dois períodos quaisquer com lançamentos, maiores gastos, tendências/insights textuais e exportação em CSV do mês selecionado.

## Próxima tarefa

Duas frentes possíveis — confirme com o usuário qual priorizar antes de codificar, já que nenhuma delas é puramente mecânica:

1. **Configurações e Ajuda** (`/configuracoes`, `/ajuda`, hoje placeholders): RF10 em `docs/03-FUNCTIONAL-REQUIREMENTS.md` lista nome, moeda, preferências de notificação, tema e segurança como "futuramente" — confirmar com o usuário o escopo real antes de implementar, já que hoje não há usuário/autenticação (Fase 6 ainda não começou).
2. **Fase 6 do roadmap (Persistência/autenticação)**: exige decisões de produto/infra que não devem ser assumidas por conta própria — qual backend, qual banco de dados, estratégia de autenticação, sincronização entre dispositivos. Não iniciar código de backend sem esse alinhamento prévio.

Se o usuário não indicar preferência, o caminho de menor risco é perguntar antes de avançar, já que ambas as frentes dependem de decisões que ainda não estão nos documentos.

Ao codificar qualquer uma das duas:
- preservar Dashboard, Transações, Cartões, Orçamento, Metas, Alertas e Análises já funcionais;
- seguir os mesmos padrões de `services/` + `hooks/` + `utils/finance.js` já estabelecidos nas fases anteriores;
- executar `npm run build`, corrigir erros;
- documentar mudanças (`CLAUDE.md`, `docs/01-CURRENT-STATE.md`, `docs/08-ROADMAP.md`, `docs/09-ACCEPTANCE-CRITERIA.md`).

Não faça uma reescrita completa sem necessidade.
