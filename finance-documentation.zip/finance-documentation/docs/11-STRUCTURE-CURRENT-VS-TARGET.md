# 11 — Estrutura atual vs. alvo

## Atual (já migrado para a estrutura alvo)

```text
finance/
├── index.html
├── package.json
├── package-lock.json
├── vite.config.js
├── CLAUDE.md
├── README.md
├── docs/
└── src/
    ├── app/
    │   ├── App.jsx
    │   └── routes.jsx
    ├── components/
    │   ├── layout/        # Sidebar.jsx, Header.jsx
    │   ├── ui/             # Modal.jsx, EmptyState.jsx, ProgressBar.jsx
    │   ├── charts/          # FinancialChart.jsx, CategoryDonut.jsx
    │   └── finance/         # TransactionRow.jsx, TransactionForm.jsx
    ├── pages/
    │   ├── Dashboard/ (funcional)
    │   ├── Transactions/ (funcional)
    │   └── Analytics/, Budget/, Goals/, Cards/, Alerts/, Settings/, Help/ (placeholders)
    ├── data/
    │   └── mockData.js
    ├── hooks/
    │   ├── useTransactions.js
    │   └── useFinanceSummary.js
    ├── services/
    │   ├── transactionService.js
    │   └── storageService.js
    ├── utils/
    │   ├── currency.js
    │   ├── dates.js
    │   └── finance.js
    ├── styles/
    │   ├── tokens.css
    │   ├── global.css
    │   ├── layout.css
    │   ├── components.css
    │   ├── pages/
    │   │   └── transactions.css
    │   └── index.css       # agrega os arquivos acima + media queries
    └── main.jsx
```

## Estratégia (progresso)

1. ~~rotas~~ ✅
2. ~~layout~~ ✅
3. ~~transações~~ ✅
4. ~~selectors financeiros~~ ✅
5. ~~Dashboard conectado~~ ✅
6. orçamento/metas/cartões — pendente (Fases 3–4);
7. análises — pendente (Fase 5);
8. persistência/backend — pendente (Fase 6, hoje é `localStorage`).

