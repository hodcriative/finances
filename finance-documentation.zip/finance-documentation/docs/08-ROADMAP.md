# 08 — Roadmap

## Fase 1 — Base visual

- [x] React + Vite
- [x] Dashboard desktop
- [x] Sidebar
- [x] Header
- [x] Cards
- [x] Gráficos visuais
- [x] Modal visual de transação
- [x] Responsividade inicial

## Fase 2 — Transações

- [x] Refatorar componentes
- [x] Rotas reais
- [x] Modelo de transação
- [x] Estado de transações
- [x] CRUD
- [x] Validação
- [x] Busca/filtros
- [x] Ordenação
- [x] Persistência local inicial
- [x] Atualização automática do Dashboard

## Fase 3 — Domínios de apoio

- [x] Categorias
- [x] Contas
- [x] Cartões representativos
- [x] Faturas manuais (valor atual editável; sem histórico de faturas por mês ainda)
- [x] Compras parceladas por cartão (descrição, valor mensal, parcelas — total derivado, adicionado após a Fase 3)

## Fase 4 — Planejamento

- [x] Orçamento geral
- [x] Orçamento por categoria
- [x] Metas
- [x] Progresso (`getBudgetUsage`, `getGoalProgress`)
- [~] Histórico — Orçamento já permite navegar por mês (cada mês tem seu próprio registro de limites, como no Dashboard); Metas ainda não guardam um histórico dos aportes individuais, só o valor acumulado atual
- [x] Alertas

## Fase 5 — Análises

- [x] Comparação mensal
- [x] Evolução anual
- [x] Categorias
- [x] Tendências
- [x] Insights
- [x] Exportação (CSV do mês selecionado)

## Configurações e Ajuda (fora da numeração de fases, RF10)

- [x] Nome exibido (Sidebar/Header)
- [x] Tema claro/escuro
- [x] Preferências de notificação (mostrar/ocultar alertas de orçamento e de metas)
- [x] Central de ajuda (FAQ estático)
- [ ] Moeda (hoje fixo em BRL)
- [ ] Primeiro dia do mês financeiro
- [ ] Segurança/login (depende da Fase 6)

## Fase 6 — Persistência/autenticação

- [ ] Definir backend
- [ ] Banco de dados
- [ ] autenticação
- [ ] API/repositories
- [ ] sincronização
- [ ] segurança

## Fase 7 — Produção

- [ ] testes
- [ ] acessibilidade
- [ ] performance
- [ ] tratamento global de erros
- [ ] observabilidade
- [ ] deploy
