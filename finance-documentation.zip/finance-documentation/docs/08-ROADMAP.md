# 08 — Roadmap

## Fase 1 — Base visual

- [x] React + Vite
- [x] Dashboard desktop
- [x] Sidebar
- [x] Header
- [x] Cards
- [x] Gráficos visuais
- [x] Modal visual de transação
- [x] Responsividade inicial

## Fase 2 — Transações

- [x] Refatorar componentes
- [x] Rotas reais
- [x] Modelo de transação
- [x] Estado de transações
- [x] CRUD
- [x] Validação
- [x] Busca/filtros
- [x] Ordenação
- [x] Persistência local inicial
- [x] Atualização automática do Dashboard

## Fase 3 — Domínios de apoio

- [x] Categorias
- [x] Contas
- [x] Cartões representativos
- [x] Faturas manuais (valor atual editável; sem histórico de faturas por mês ainda)
- [x] Compras parceladas por cartão (descrição, valor mensal, parcelas — total derivado, adicionado após a Fase 3)

## Fase 4 — Planejamento

- [x] Orçamento geral
- [x] Orçamento por categoria
- [x] Metas
- [x] Progresso (`getBudgetUsage`, `getGoalProgress`)
- [~] Histórico — Orçamento já permite navegar por mês (cada mês tem seu próprio registro de limites, como no Dashboard); Metas ainda não guardam um histórico dos aportes individuais, só o valor acumulado atual
- [x] Alertas

## Fase 5 — Análises

- [x] Comparação mensal
- [x] Evolução anual
- [x] Categorias
- [x] Tendências
- [x] Insights
- [x] Exportação (CSV do mês selecionado)

## Configurações e Ajuda (fora da numeração de fases, RF10)

- [x] Nome exibido (Sidebar/Header)
- [x] Tema claro/escuro
- [x] Preferências de notificação (mostrar/ocultar alertas de orçamento e de metas)
- [x] Central de ajuda (FAQ estático)
- [ ] Moeda (hoje fixo em BRL)
- [ ] Primeiro dia do mês financeiro
- [ ] Segurança/login (depende da Fase 6)

## Fase 6 — Persistência/autenticação

- [x] Definir backend (Node.js + Express + SQLite via `node:sqlite`, alinhado com o usuário)
- [x] Banco de dados (schema SQLite em `server/src/db.js`, espelha `docs/04-DATA-MODEL.md`)
- [x] Autenticação (e-mail/senha, `bcryptjs` + JWT, testado via curl incluindo isolamento entre usuários)
- [x] API/repositories (rotas de todos os domínios em `server/src/routes/`, ver `server/README.md`)
- [ ] Integração do frontend com a API (`services/*.js` ainda usam `localStorage`; telas de login/registro e proteção de rotas ainda não existem)
- [ ] sincronização (migração dos dados hoje em `localStorage` — combinado que fica para depois, backend começa zerado)
- [ ] segurança (revisão mais ampla — ex.: rate limiting, refresh token — só depois da integração do frontend)

## Fase 7 — Produção

- [ ] testes
- [ ] acessibilidade
- [ ] performance
- [ ] tratamento global de erros
- [ ] observabilidade
- [ ] deploy
