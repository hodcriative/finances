# FINANCE — Plataforma de Organização Financeira Pessoal

Handoff técnico e funcional do projeto para continuidade com outro desenvolvedor/IA (incluindo Claude).

## Regra de negócio principal

**A plataforma NÃO movimenta dinheiro real.**

Ela não realiza pagamentos, transferências, investimentos, saques, depósitos ou qualquer operação financeira real. Também não controla nem movimenta cartões bancários.

Contas e cartões são apenas registros informativos para organização. Receitas, despesas, faturas, limites, metas e orçamentos são informados/gerenciados manualmente pelo usuário.

## Stack atual

- React 18
- Vite 6
- React Router DOM 7, com rotas declarativas reais em `src/app/routes.jsx` (`<Routes>`/`<Route>`)
- lucide-react
- JavaScript/JSX
- CSS puro com variáveis de design, dividido em `src/styles/{tokens,global,layout,components}.css` e `src/styles/pages/`

## Estado do produto (pós Fase 2 do roadmap)

- Dashboard, Transações: funcionais, conectados a dados reais persistidos em `localStorage`.
- Análises, Orçamento, Metas, Cartões, Alertas, Configurações, Ajuda: placeholders (Fases 3–7).

Veja `docs/01-CURRENT-STATE.md` e `docs/08-ROADMAP.md` para o detalhamento.

## Executar

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
```

## Documentação

Consulte `CLAUDE.md` para instruções de continuidade e `docs/` para documentação detalhada.

